import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { DistrictData } from '../types';

interface SearchBarProps {
  districts: DistrictData[];
  onDistrictSelect: (district: DistrictData) => void;
}

export function SearchBar({ districts, onDistrictSelect }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const filteredDistricts = districts.filter(district =>
    district.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="relative w-full max-w-md">
      <div className="relative">
        <input
          type="text"
          className="w-full px-4 py-2 pl-10 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Search districts..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
        />
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
      </div>
      
      {isOpen && query && (
        <div className="absolute z-10 w-full mt-1 bg-white rounded-lg shadow-lg">
          {filteredDistricts.map(district => (
            <button
              key={district.id}
              className="w-full px-4 py-2 text-left hover:bg-gray-100"
              onClick={() => {
                onDistrictSelect(district);
                setQuery('');
                setIsOpen(false);
              }}
            >
              {district.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}