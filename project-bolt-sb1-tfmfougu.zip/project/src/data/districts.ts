import { DistrictData } from '../types';

export const districtData: DistrictData[] = [
  {
    id: 'chennai',
    name: 'Chennai',
    data: {
      required: 500000,
      used: 300000,
      storage: 700000
    }
  },
  {
    id: 'coimbatore',
    name: 'Coimbatore',
    data: {
      required: 350000,
      used: 200000,
      storage: 600000
    }
  },
  {
    id: 'madurai',
    name: 'Madurai',
    data: {
      required: 250000,
      used: 150000,
      storage: 500000
    }
  },
  {
    id: 'trichy',
    name: 'Trichy',
    data: {
      required: 280000,
      used: 170000,
      storage: 450000
    }
  },
  {
    id: 'salem',
    name: 'Salem',
    data: {
      required: 220000,
      used: 130000,
      storage: 400000
    }
  },
  {
    id: 'tirunelveli',
    name: 'Tirunelveli',
    data: {
      required: 180000,
      used: 120000,
      storage: 350000
    }
  },
  {
    id: 'erode',
    name: 'Erode',
    data: {
      required: 200000,
      used: 140000,
      storage: 380000
    }
  },
  {
    id: 'vellore',
    name: 'Vellore',
    data: {
      required: 190000,
      used: 110000,
      storage: 320000
    }
  },
  {
    id: 'thanjavur',
    name: 'Thanjavur',
    data: {
      required: 230000,
      used: 160000,
      storage: 420000
    }
  },
  {
    id: 'dindigul',
    name: 'Dindigul',
    data: {
      required: 170000,
      used: 100000,
      storage: 300000
    }
  },
  {
    id: 'kanyakumari',
    name: 'Kanyakumari',
    data: {
      required: 160000,
      used: 90000,
      storage: 280000
    }
  },
  {
    id: 'cuddalore',
    name: 'Cuddalore',
    data: {
      required: 185000,
      used: 115000,
      storage: 330000
    }
  },
  {
    id: 'thoothukudi',
    name: 'Thoothukudi',
    data: {
      required: 175000,
      used: 105000,
      storage: 310000
    }
  },
  {
    id: 'tiruppur',
    name: 'Tiruppur',
    data: {
      required: 210000,
      used: 145000,
      storage: 390000
    }
  },
  {
    id: 'karur',
    name: 'Karur',
    data: {
      required: 155000,
      used: 95000,
      storage: 270000
    }
  }
];