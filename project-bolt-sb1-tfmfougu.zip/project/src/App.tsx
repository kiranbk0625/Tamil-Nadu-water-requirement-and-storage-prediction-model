import React, { useState } from 'react';
import { CropIcon as WaterDropIcon } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { WaterStats } from './components/WaterStats';
import { Footer } from './components/Footer';
import { districtData } from './data/districts';
import { DistrictData } from './types';

function App() {
  const [selectedDistrict, setSelectedDistrict] = useState<DistrictData | null>(null);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <WaterDropIcon className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-800">Tamil Nadu Water Dashboard</h1>
            </div>
            <SearchBar 
              districts={districtData}
              onDistrictSelect={setSelectedDistrict}
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {selectedDistrict ? (
          <WaterStats 
            districtName={selectedDistrict.name}
            data={selectedDistrict.data}
          />
        ) : (
          <div className="text-center py-12">
            <WaterDropIcon className="h-16 w-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-gray-700 mb-2">
              Welcome to Tamil Nadu Water Dashboard
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Select a district using the search bar above to view detailed water statistics 
              including requirements, usage, and storage capacity.
            </p>
          </div>
        )}

        {/* District Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mt-8">
          {districtData.map(district => (
            <button
              key={district.id}
              className="p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
              onClick={() => setSelectedDistrict(district)}
            >
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{district.name}</h3>
              <div className="flex flex-col gap-1 text-sm text-gray-600">
                <span>Storage: {district.data.storage.toLocaleString()} m³</span>
                <span>Used: {district.data.used.toLocaleString()} m³</span>
              </div>
            </button>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;