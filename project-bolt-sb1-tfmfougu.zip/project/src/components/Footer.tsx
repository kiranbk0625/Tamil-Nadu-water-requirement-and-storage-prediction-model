import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8 mt-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
            <div className="space-y-2">
              <p className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>+91 44 2345 6789</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>water@tn.gov.in</span>
              </p>
              <p className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>Chennai, Tamil Nadu</span>
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-blue-400">About Us</a></li>
              <li><a href="#" className="hover:text-blue-400">Water Conservation Tips</a></li>
              <li><a href="#" className="hover:text-blue-400">Report Issues</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Emergency</h3>
            <p className="mb-2">24/7 Water Emergency Helpline</p>
            <p className="text-2xl font-bold text-blue-400">1800-425-1234</p>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-700 text-center">
          <p>&copy; 2024 Tamil Nadu Water Resources Department. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}