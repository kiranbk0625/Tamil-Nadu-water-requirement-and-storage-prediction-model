export interface WaterData {
  required: number;
  used: number;
  storage: number;
}

export interface DistrictData {
  id: string;
  name: string;
  data: WaterData;
}