import React from 'react';
import { Chart as ChartJS, ArcElement, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { Pie, Line } from 'react-chartjs-2';
import { WaterData } from '../types';
import { Droplets, Database, Timer } from 'lucide-react';

ChartJS.register(
  ArcElement,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface WaterStatsProps {
  districtName: string;
  data: WaterData;
}

export function WaterStats({ districtName, data }: WaterStatsProps) {
  const pieData = {
    labels: ['Used', 'Available'],
    datasets: [
      {
        data: [data.used, data.storage - data.used],
        backgroundColor: ['#3B82F6', '#60A5FA'],
        borderColor: ['#2563EB', '#3B82F6'],
        borderWidth: 1,
      },
    ],
  };

  const lineData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Projected Requirements',
        data: Array(6).fill(null).map(() => Math.random() * data.required),
        borderColor: '#3B82F6',
        tension: 0.4,
      },
    ],
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">{districtName} Water Statistics</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="p-4 bg-blue-50 rounded-lg">
          <div className="flex items-center gap-3 mb-2">
            <Droplets className="text-blue-600" />
            <h3 className="font-semibold text-gray-700">Required Water</h3>
          </div>
          <p className="text-2xl font-bold text-blue-600">{data.required.toLocaleString()} m³</p>
        </div>
        
        <div className="p-4 bg-green-50 rounded-lg">
          <div className="flex items-center gap-3 mb-2">
            <Timer className="text-green-600" />
            <h3 className="font-semibold text-gray-700">Water Used</h3>
          </div>
          <p className="text-2xl font-bold text-green-600">{data.used.toLocaleString()} m³</p>
        </div>
        
        <div className="p-4 bg-purple-50 rounded-lg">
          <div className="flex items-center gap-3 mb-2">
            <Database className="text-purple-600" />
            <h3 className="font-semibold text-gray-700">Storage Capacity</h3>
          </div>
          <p className="text-2xl font-bold text-purple-600">{data.storage.toLocaleString()} m³</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold mb-4 text-gray-700">Current Usage vs Capacity</h3>
          <div className="h-64">
            <Pie data={pieData} options={{ maintainAspectRatio: false }} />
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-4 text-gray-700">Projected Requirements</h3>
          <div className="h-64">
            <Line data={lineData} options={{ maintainAspectRatio: false }} />
          </div>
        </div>
      </div>
    </div>
  );
}